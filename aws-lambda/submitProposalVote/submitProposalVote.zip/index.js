const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({region: "us-east-1"});

const decode = (encrypted) => {
    let bufferObj = Buffer.from(encrypted, "base64");
    return bufferObj.toString("utf8");
};

const getProposal = async (proposalId) => {
    let params = {
        Key: {
            "proposal_id": proposalId
        },
        TableName: "dao_proposal"
    };

    let result = await docClient.get(params).promise();
    console.log("getProposal", result);
    return result;
};

const updateVote = async (proposalId, userAddress) => {
    let params = {
        TableName: "dao_proposal",
        Key:{
            "proposal_id": proposalId,
        },
        UpdateExpression: 'SET vote_count = vote_count + :increase, voter_addresses = list_append(voter_addresses, :userAddress)',
        ExpressionAttributeValues:{
            ":increase": 1,
            ":userAddress": [userAddress]
        },
        ReturnValues: "UPDATED_NEW"
    };

    let result = await docClient.update(params).promise();
    console.log("updateVote", result);
    return result;
}

//POST, supply JSON with "proposal_id" and "user_address" as string
//returns updated proposal json
exports.handler = async (event) => {
    try {
        console.log("Processing:", event);
        let decoded = decode(event.body);
        var obj = JSON.parse(decoded);
    
        let getProposalResult = await getProposal(obj.proposal_id);
        if (!getProposalResult || !getProposalResult.Item) {
            let response = "Proposal not found or missing data";
            console.error(response, getProposalResult);
            return {
                statusCode: 400,
                body: response
            };
        }

        if (getProposalResult.Item.status != "OPEN") {
            let response = "Proposal is not open, status=" + getProposalResult.Item.status;
            console.error(response);
            return {
                statusCode: 400,
                body: response
            };
        }
        
        if (getProposalResult.Item.voter_addresses.includes(obj.user_address)) {
            let response = "User already voted";
            console.error(response);
            return {
                statusCode: 400,
                body: response
            };
        }

        let updateVoteResult = await updateVote(obj.proposal_id, obj.user_address);
        return {
            statusCode: 200,
            body: updateVoteResult
        };        
    } catch (error) {
        console.error(error);
        return error;
    }
};